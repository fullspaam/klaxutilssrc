package net.spaam.klax.module.modules.klax;

import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.spaam.klax.event.events.TickListener;
import net.spaam.klax.module.Category;
import net.spaam.klax.module.Module;
import net.spaam.klax.utils.InventoryUtils;

public final class T0temUtil extends Module implements TickListener {
    private static final int SWITCH_DELAY = 0;
    private static final int EQUIP_DELAY = 1;
    private static final boolean SWITCH_BACK = true;

    private int switchClock, equipClock, switchBackClock;
    private int previousSlot = -1;
    boolean sent, active = false;

    public T0temUtil() {
        super("Text1", "Text2", -1, Category.modrinth);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        reset();

        super.onEnable();
    }

    @Override
    public void onDisable() {

    }

    @Override
    public void setEnabled(boolean enabled) {
        if (enabled) {
            if (!isEnabled()) {
                super.setEnabled(true);
            }
        }
    }

    @Override
    public void setEnabledStatus(boolean enabled) {
        if (enabled) {
            super.setEnabledStatus(true);
        }
    }

    @Override
    public void toggle() {
        if (!isEnabled()) {
            super.setEnabled(true);
        }
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1755 != null)
            return;

        if(mc.field_1724.method_6079().method_7909() == class_1802.field_8288) {
            if(active) {
                if (SWITCH_BACK && previousSlot != -1)
                    InventoryUtils.setInvSlot(previousSlot);
                reset();
                active = false;
            }
            return;
        }

        if(!active) {
            active = true;
            previousSlot = mc.field_1724.method_31548().field_7545;
        }

        if(active) {
            if (switchClock < SWITCH_DELAY) {
                switchClock++;
                return;
            }

            if (InventoryUtils.selectItemFromHotbar(class_1802.field_8288)) {
                if (equipClock < EQUIP_DELAY) {
                    equipClock++;
                    return;
                }

                if (!sent) {
                    mc.method_1562().method_48296().method_10743(new class_2846(class_2846.class_2847.field_12969, class_2338.field_10980, class_2350.field_11033));
                    sent = true;
                }
            }
        }
    }

    public void reset() {
        switchClock = 0;
        equipClock = 0;
        switchBackClock = 0;
        previousSlot = -1;

        sent = false;
        active = false;
    }
}