package net.spaam.klax.utils;
import static net.spaam.klax.Klax.mc;
import java.awt.*;
import net.minecraft.class_1297;
import net.minecraft.class_640;

public final class Utils {

	public static int getPing(class_1297 player) {
		if (mc.method_1562().method_48296() == null) return 0;

		class_640 playerListEntry = mc.method_1562().method_2871((player.method_5667()));
		if (playerListEntry == null) return 0;
		return playerListEntry.method_2959();
	}
}
