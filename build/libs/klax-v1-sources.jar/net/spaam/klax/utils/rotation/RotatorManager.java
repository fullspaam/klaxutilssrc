package net.spaam.klax.utils.rotation;

import net.spaam.klax.Klax;
import net.spaam.klax.event.EventManager;
import net.spaam.klax.event.events.*;
import net.spaam.klax.utils.RotationUtils;

import static net.spaam.klax.Klax.mc;

import net.minecraft.class_2708;
import net.minecraft.class_2828;


public final class RotatorManager implements PacketSendListener, BlockBreakingListener, ItemUseListener, AttackListener, MovementPacketListener, PacketReceiveListener {
	private boolean enabled;
	private boolean rotateBack;
	private boolean resetRotation;
	private final EventManager eventManager = Klax.INSTANCE.eventManager;
	private Rotation currentRotation;
	private float clientYaw, clientPitch;
	private float serverYaw, serverPitch;

	public RotatorManager() {
		eventManager.remove(PacketSendListener.class, this);
		eventManager.remove(AttackListener.class, this);
		eventManager.remove(ItemUseListener.class, this);
		eventManager.remove(MovementPacketListener.class, this);
		eventManager.remove(PacketReceiveListener.class, this);
		eventManager.remove(BlockBreakingListener.class, this);


		enabled = true;
		rotateBack = false;
		resetRotation = false;

		this.serverYaw = 0;
		this.serverPitch = 0;

		this.clientYaw = 0;
		this.clientPitch = 0;
	}

	public void shutDown() {
		eventManager.remove(PacketSendListener.class, this);
		eventManager.remove(AttackListener.class, this);
		eventManager.remove(ItemUseListener.class, this);
		eventManager.remove(MovementPacketListener.class, this);
		eventManager.remove(PacketReceiveListener.class, this);
		eventManager.remove(BlockBreakingListener.class, this);
	}

	public Rotation getServerRotation() {
		return new Rotation(serverYaw, serverPitch);
	}

	public void enable() {
		enabled = true;
		rotateBack = false;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void disable() {
		if (isEnabled()) {
			enabled = false;
			if (!rotateBack) rotateBack = true;
		}
	}

	public void setRotation(Rotation rotation) {
		currentRotation = rotation;
	}

	public void setRotation(double yaw, double pitch) {
		setRotation(new Rotation(yaw, pitch));
	}

	private void resetClientRotation() {
		mc.field_1724.method_36456(clientYaw);
		mc.field_1724.method_36457(clientPitch);

		resetRotation = false;
	}

	public void setClientRotation(Rotation rotation) {
		this.clientYaw = mc.field_1724.method_36454();
		this.clientPitch = mc.field_1724.method_36455();

		mc.field_1724.method_36456((float) rotation.yaw());
		mc.field_1724.method_36457((float) rotation.pitch());

		resetRotation = true;
	}

	public void setServerRotation(Rotation rotation) {
		this.serverYaw = (float) rotation.yaw();
		this.serverPitch = (float) rotation.pitch();
	}

	private boolean wasDisabled;

	@Override
	public void onAttack(AttackEvent event) {
		if (!isEnabled() && wasDisabled) {
			enabled = true;
			wasDisabled = false;
		}
	}

	@Override
	public void onItemUse(ItemUseEvent event) {
		if (!event.isCancelled() && isEnabled()) {
			enabled = false;
			wasDisabled = true;
		}
	}

	@Override
	public void onPacketSend(PacketSendEvent event) {
		if (event.packet instanceof class_2828 packet) {
			serverYaw = packet.method_12271(serverYaw);
			serverPitch = packet.method_12270(serverPitch);
		}
	}

	@Override
	public void onBlockBreaking(BlockBreakingEvent event) {
		if (!event.isCancelled() && isEnabled()) {
			enabled = false;
			wasDisabled = true;
		}
	}

	@Override
	public void onSendMovementPackets() {
		if (isEnabled() && currentRotation != null) {
			setClientRotation(currentRotation);
			setServerRotation(currentRotation);

			return;
		}

		if (rotateBack) {
			Rotation serverRot = new Rotation(serverYaw, serverPitch);
			Rotation clientRot = new Rotation(mc.field_1724.method_36454(), mc.field_1724.method_36455());

			if (RotationUtils.getTotalDiff(serverRot, clientRot) > 1) {
				Rotation smoothRotation = RotationUtils.getSmoothRotation(serverRot, clientRot, 0.2);

				setClientRotation(smoothRotation);
				setServerRotation(smoothRotation);
			} else {
				rotateBack = false;
			}
		}
	}

	@Override
	public void onPacketReceive(PacketReceiveEvent event) {
		if (event.packet instanceof class_2708 packet) {
			serverYaw = packet.method_11736();
			serverPitch = packet.method_11739();
		}
	}
}