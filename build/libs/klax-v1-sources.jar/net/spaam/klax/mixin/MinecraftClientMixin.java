package net.spaam.klax.mixin;

import net.minecraft.class_310;
import net.spaam.klax.event.EventManager;
import net.spaam.klax.event.events.TickListener;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftClientMixin {
	@Inject(method = "tick", at = @At("HEAD"))
	private void onTick(CallbackInfo ci) {
		EventManager.fire(new TickListener.TickEvent());
	}
}
